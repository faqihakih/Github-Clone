package com.akih.submission2bfaa.data

data class ListUser (
    val items : ArrayList<Users>
)